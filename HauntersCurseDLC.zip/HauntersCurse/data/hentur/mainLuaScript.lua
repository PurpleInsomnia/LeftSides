function onCreate()
    makeLuaSprite("blackfadething", "black", 0, 0);
    setObjectCamera("blackfadething", "camHUD");
    addLuaSprite("blackfadething", false);
end

function onCreatePost()
    changeIconP1("color-pixel");
    setHealthbarColor("00ADFF", "6D6D6D");

    setProperty("boyfriend.visible", false);
    setProperty("gf.visible", false);

    setProperty("camMoveOffset", 5);

    doTweenY("floatiefloatfloat", "dad", getProperty("dad.y") - 15, crochet / 500, "sineInOut:pingpong");

    setProperty("skipCountdown", true);
end

-- cache Ig :/
function onBeatHit()
    if curBeat == 1 or curBeat == 5 then
        triggerEvent("Ball", "", "off");
    end
end

function opponentNoteHit()
    if getProperty("blackfadething.alpha") == 1 then
       setProperty("blackfadething.alpha", 0); 
    end
end