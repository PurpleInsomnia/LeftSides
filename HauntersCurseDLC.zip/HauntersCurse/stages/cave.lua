function onCreate()
    makeLuaSprite("bg", "lullaby/bootleg/bg", 0, 0);
    setProperty("bg.antialiasing", false);
    addLuaSprite("bg", false);

    makeLuaSprite("shader", "lullaby/bootleg/shader", 0, 0);
    setProperty("shader.antialiasing", false);
    addLuaSprite("shader", true);
end

function onCreatePost()
    -- android ahh screen center :skull:
    triggerEvent('Camera Follow Pos', 144, 90);
end