function onCreate()
    setProperty("bfZoom", true);
    
    makeLuaSprite("bg", "lullaby/haunter/bg", -200, -100);
    addLuaSprite("bg", false);

    makeLuaSprite("floor", "lullaby/haunter/floor", -200, -100);
    addLuaSprite("floor", false);

    makeLuaSprite("snow", "lullaby/haunter/snow", -200, -100);
    addLuaSprite("snow", true);

    makeLuaSprite("shader", "lullaby/haunter/shader", -200, -100);
    setBlendMode("shader", "add");
    addLuaSprite("shader", true);
end

function onCreatePost()
    setProperty("gf.visible", false);
end