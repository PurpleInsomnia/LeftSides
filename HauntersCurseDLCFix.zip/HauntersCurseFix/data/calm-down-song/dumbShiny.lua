function onCreate()
    makeLuaSprite("fadething", "black", 0, 0);
    setObjectCamera("fadething", "camBars");
    setProperty("fadething.alpha", 0);
    addLuaSprite("fadething", false);

    toAdd = "";
    if getPropertyFromClass("PlayState", "isPixelStage") then
        toAdd = "-pixel";
    end
    makeLuaSprite("particle", "lullaby/ui/shinyParticle" .. toAdd, 0, 0);
    setProperty("particle.alpha", 0);
    if getPropertyFromClass("PlayState", "isPixelStage") then
        setProperty("particle.antialiasing", false);
    end
    addLuaSprite("particle", true);
end

function onUpdatePost()
    --setProperty("particle.x", (getProperty("dad.x") + getProperty("dad.width") - ((getProperty("dad.width") / 2) - (getProperty("particle.width") / 2))));
    --setProperty("particle.y", (getProperty("dad.y") + getProperty("dad.height") - ((getProperty("dad.height") / 2)  - (getProperty("particle.width") / 2))));
    setProperty("particle.x", getProperty("dad.x") + (getProperty("particle.width") / 2));
    setProperty("particle.y", getProperty("dad.y") + (getProperty("particle.height") / 2));
end

function onShinyConfirm()
    setProperty("particle.alpha", 1);
    setProperty("fadething.alpha", 0.5);
    runTimer("fadethings", 0.5);
    doTweenAlpha("particles", "particle", 0, 1, "linear");
end

function onTimerCompleted(tag)
    if tag == "fadethings" then
        doTweenAlpha("fadethinge", "fadething", 0, 0.5, "linear");
    end
end