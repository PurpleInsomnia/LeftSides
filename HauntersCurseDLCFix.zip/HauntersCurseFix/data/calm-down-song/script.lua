function onCreatePost()
    setProperty("gf.visible", false);
    setProperty("gameoverscript", "calmDown");

    makeLuaSprite("fadelmao", "black", 0, 0);
    setObjectCamera("fadelmao", "camHUD");
    addLuaSprite("fadelmao", true);
end

function onCountdownTick(counter)
    if counter == 0 then
        doTweenY("floatiefloatfloat", "dad", getProperty("dad.y") - 75, crochet / 500, "sineInOut:pingpong");
        doTweenAlpha("fadethew", "fadelmao", 0, crochet / 500, "linear");
    end
end

function onStepHit()
    if curStep == 1 then
        callOnLuas("shinyTrigger");
    end
    if curStep == 1024 then
        setProperty("fadelmao.alpha", 1);
    end
end