function onGameOverInit()
    return Function_Stop;
end

local allowCountdown = false;
function onStartCountdown()
	-- if not allowCountdown and isStoryMode and not seenCutscene then
		-- allowCountdown = true;
        -- callOnLuas("onStartHenturCutscene");
		-- return Function_Stop;
	-- end
	-- return Function_Continue;
end