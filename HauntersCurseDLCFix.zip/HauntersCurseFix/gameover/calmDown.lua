function onCreate()
    setProperty("musicName", "gameOverLullaby");

    playSound("lullaby/haunter/deathCalm");

    makeLuaSprite("bg", "lullaby/ui/retry", 0, 0);
    setProperty("bg.alpha", 0);
    addLuaSprite("bg");

    cameraFlash("FF0000", 1, true);

    runTimer("the timer", 1);
end

function onTimerCompleted(tag)
    if tag == "the timer" then
        doTweenAlpha("bgTween", "bg", 1, 0.5, "linear");
        setProperty("canPress", true);
        playMusic(1, true);
    end
end

local can = false;
function onUpdate(elapsed)
    can = getProperty("canPress");
    if keyJustPressed("accept") and can then
        setProperty("canPress", false);
        setProperty("bg.alpha", 0);
        switchState("bruh");
        playSound("lullaby/haunter/confirm");
        cameraFlash("FFFFFF", 1, true);
    end
    if keyJustPressed("back") and can then
        setProperty("canPress", false);
        back("bruh");
    end
end