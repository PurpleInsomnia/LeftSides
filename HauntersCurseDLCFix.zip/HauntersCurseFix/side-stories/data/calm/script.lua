function onCreate()
	makeLuaSprite("bs", "blackScreen", 0, 0);
	setProperty("bs.alpha", 0);
	addLuaSprite("bs", true);

    setProperty("stopClose", true);
end

function onNextLinePost(line)
    if line == 10 then
        timeCard("essay");
    end
    if line == 16 or line == 22 then
        timeCard("moment");
    end
    if line == 30 then
        setProperty("luaControlNext", true);
        doTrans();
    end
end

function doTrans()
	blackFade("in", 3);
	startTimer("transTimer", 3);
end

function onTimerCompleted(tag)
	if tag == "transTimer" then
        endState();
	end
end

function blackFade(type, sec)
	if type == "in" then
		doTweenAlpha("bsti", "bs", 1, sec, "linear");
	end
end

function onEnd()
    loadStoryMode("Calm Down Song|Hentur", 50);
end